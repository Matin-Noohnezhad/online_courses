package com.example.flashcard_project.utils;

import com.example.flashcard_project.beans.FlashCard;

public interface CardClickListener {

    void onCardClicked(FlashCard card);

}
